module.exports = {
    devServer: {
        disableHostCheck: true,
    },
    // css: {
    //     loaderOptions: {
    //         postcss: {
    //             plugins: [
    //                 require("postcss-px2rem")({
    //                     // 以设计稿750为例， 750 / 10 = 75
    //                     remUnit: 35,
    //                 }),
    //             ],
    //         },
    //     },
    // },
};
