<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<style lang="less">
body {
  padding: 0;
  margin: 0;
}
</style>
