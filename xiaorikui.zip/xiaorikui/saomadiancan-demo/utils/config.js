// 配置服务器相关信息
export default {
    host: "http://localhost/phpsaomaserver",
    hostserve: "http://119.23.63.87/phpsaomaserver",
};
